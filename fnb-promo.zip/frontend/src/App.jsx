import React, { useState, useEffect } from "react";

function App() {
  const [promoCode, setPromoCode] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [isUsed, setIsUsed] = useState(false);

  const validCode = "NUSANTARA";
  const voucherImage = "/voucher.png";
  const phoneNumber = "6282252550791"; // ganti dengan nomor WA kamu

  // Cek apakah kode sudah pernah digunakan di browser
  useEffect(() => {
    const used = localStorage.getItem("promoUsed");
    if (used === "true") setIsUsed(true);
  }, []);

  const handleApply = async () => {
  try {
    const res = await fetch("http://localhost:5000/api/check-code", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code: promoCode.toUpperCase() }),
    });

    const data = await res.json();

    if (!data.success) {
      alert(data.message);
      return;
    }

    // Kalau valid, tampilkan voucher
    setShowModal(true);

    // Tandai kode sudah digunakan
    await fetch("http://localhost:5000/api/use-code", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code: promoCode.toUpperCase() }),
    });

  } catch (err) {
    console.error(err);
    alert("Terjadi kesalahan server!");
  }
};


  const handleWhatsApp = () => {
    const voucherLink = `${window.location.origin}${voucherImage}`;
    const message = `Halo! Saya ingin menggunakan voucher Diskon 25% 🎉\nBerikut gambar vouchernya:\n${voucherLink}`;
    window.open(
      `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`,
      "_blank"
    );
  };

  return (
    <div className="min-vh-100 d-flex flex-column justify-content-center align-items-center text-center bg-warning-subtle p-3">
      <div className="container">
        <h1 className="fw-bold text-warning mb-3 display-6">
          🍜 PROMO SPESIAL NUSANTARA 🍹
        </h1>
        <p className="text-secondary fs-5 mb-4">
          Masukkan kode promo untuk mendapatkan{" "}
          <b>Voucher Diskon 25%</b> 🎁
        </p>

        <div className="card shadow-sm border-0 mx-auto" style={{ maxWidth: "420px" }}>
          <div className="card-body">
            <input
              type="text"
              className="form-control text-center mb-3"
              placeholder="Masukkan kode promo..."
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value)}
              disabled={isUsed}
            />
            <button
              className="btn btn-warning text-white fw-bold w-100"
              onClick={handleApply}
              disabled={isUsed}
            >
              {isUsed ? "Kode Sudah Digunakan 🔒" : "Gunakan Kode 🎟️"}
            </button>
          </div>
        </div>

        <footer className="mt-4 text-muted small">
          © 2025 Nusantara F&B • Promo berlaku sampai 31 Desember 🍽️
        </footer>
      </div>

      {/* Modal Voucher */}
      {showModal && (
        <div
          className="modal fade show"
          style={{
            display: "block",
            backgroundColor: "rgba(0,0,0,0.6)",
          }}
        >
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content border-0 shadow-lg rounded-4">
              <div className="modal-header border-0">
                <h5 className="modal-title text-warning fw-bold">
                  🎉 Voucher Diskon 25%
                </h5>
                <button
                  type="button"
                  className="btn-close"
                  onClick={() => setShowModal(false)}
                ></button>
              </div>
              <div className="modal-body text-center">
                <img
                  src={voucherImage}
                  alt="Voucher Diskon 25%"
                  className="img-fluid rounded-3 mb-3"
                  style={{ maxWidth: "80%", height: "auto" }}
                />
                <p className="text-muted">
                  Tunjukkan voucher ini ke kasir untuk menikmati promo 🎁
                </p>
              </div>
              <div className="modal-footer border-0 justify-content-center">
                <button
                  className="btn btn-success"
                  onClick={handleWhatsApp}
                >
                  Kirim via WhatsApp 💬
                </button>
                <button
                  className="btn btn-secondary"
                  onClick={() => setShowModal(false)}
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
