import express from "express";
import cors from "cors";
import fs from "fs";
import path from "path";

const app = express();
const PORT = process.env.PORT || 5000;
const __dirname = path.resolve();

app.use(cors());
app.use(express.json());

// 🔗 API folder frontend agar bisa di-deploy bareng
app.use(express.static(path.join(__dirname, "frontend", "dist")));

const promoFile = "./backend/promo.json";

// ✅ Cek kode promo
app.post("/check-code", (req, res) => {
  const { code } = req.body;
  const promos = JSON.parse(fs.readFileSync(promoFile));

  if (!promos[code]) {
    return res.status(404).json({ message: "Kode tidak valid!" });
  }

  if (promos[code].used) {
    return res.status(400).json({ message: "Kode sudah digunakan!" });
  }

  promos[code].used = true;
  fs.writeFileSync(promoFile, JSON.stringify(promos, null, 2));

  res.json({ discount: promos[code].discount });
});

// 🧭 Semua rute selain API diarahkan ke React
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "frontend", "dist", "index.html"));
});

app.listen(PORT, () => console.log(`✅ Server berjalan di port ${PORT}`));
